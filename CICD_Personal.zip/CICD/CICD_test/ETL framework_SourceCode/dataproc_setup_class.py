from google.cloud import dataproc_v1 as dataproc
import traceback
import sys


class DataprocCluster:
    """Initialization of Dataproc Cluster Class. Use to set values for cluster name, region, project id.
    
    Attributes:
        cluster_name (str): Name of the cluster.
        project_id (str): Project ID of the project associated with the cluster.
        region (str): Region associated with the project.
        cluster_client (google.cloud.dataproc_v1.services.cluster_controller.ClusterControllerClient): Cluster Controller associated with this cluster.
        job_client (google.cloud.dataproc_v1.services.job_controller.JobControllerClient): Job Controller used for submitting jobs in the cluster.

    Args:
        cluster_name (str): Name to use for creating a cluster.
        project_id (str): Project to use for creating resources.
        region (str): Region where the resources should live.

    Example:
        >>> obj = DataprocCluster("test-rj", "gdw-dev-smai-vtctrimopt", "us-west1")

    """

    def __init__(self, cluster_name, project_id="", region=""):

        self.cluster_name = cluster_name
        self.project_id = project_id
        self.region = region
        self.cluster_client = dataproc.ClusterControllerClient(client_options={"api_endpoint": f"{region}-dataproc.googleapis.com:443"})
        self.job_client = dataproc.JobControllerClient(client_options={"api_endpoint": "{}-dataproc.googleapis.com:443".format(region)})

    def create_cluster(self,
                       master_machine_type="n1-standard-4",
                       worker_machine_type="n1-standard-4",
                       num_of_workers=2,
                       image_version='2.0-debian10',
                       autoscale_policy='',
                       config_bucket_name='',
                       external_package="google-cloud-storage==1.38.0  git+https://bitbucket.micron.com/bbdc/scm/bd_at/tte_index_api.git",
                       spark_jars="gs://gdw-prod-data-probe-lib/spark-probe-trevni-3.1.1-DEV.jar,gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar",
                       spark_jar_repos="https://boartifactory.micron.com:443/artifactory/gdw-maven-prod-virtual",
                       spark_jars_packages="com.micron.spark.probe.trevni:spark-probe-trevni:3+"):
        #"gs://gdw-prod-data-probe-lib/spark-probe-trevni-3.1.1-DEV.jar,gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar,gs://gdw-prod-data-tte/repos/scala/release/com/micron/pesoft/tteq-2.3.0.jar"
        """Create the cloud Dataproc cluster using the python Cloud Client Library.

        Args:
            master_machine_type (str): Specification of master node.
            worker_machine_type (str): Specification of child nodes.
            num_of_workers (int): Specify number of worker nodes.
            image_version (str): Specify OS Distribution.
            autoscale_policy (str): Specify Autoscaling Policy config associated with the cluster. Autoscaling will be disabled if this argument is not specified.
            config_bucket_name (str): Specify the Cloud Storage bucket that should be used to stage job dependencies, config files, and job driver console output
            external_package([str],str): External pip packages to be included to all instances in the cluster. Specify as space seperated string or list.
            spark_jars ([str]/str): List of spark jars to be included in the cluster. Specify as list of strings or ',' seperated string.
            spark_jar_repos (str): List of spark jar repos to be included in the cluster. Specify as ',' seperated string.
            spark_jars_packages (str): List of spark jar repos to be included in the cluster. Specify as ',' seperated string.

        Returns:
            (google.api_core.operation_async.AsyncOperation): object corresponding to Create cluster operation.

        Example:
            >>> obj = DataprocCluster("test-cluster", "gdw-dev-smai-vtctrimopt", "us-west1")
            >>> obj.create_cluster(master_machine_type="n1-standard-4", worker_machine_type="n1-standard-4",\
                image_version='2.0-debian10',num_of_workers = 2,\
                config_bucket_name="gdw-dev-smai-vtctrimopt-default",\
                autoscale_policy="gdw-dev-smai-vtctrimopt-autoscaling-2-10",\
                spark_jars=["gs://spark-lib/bigquery/spark-2.4-bigquery-0.23.2-preview.jar", "gs://gdw-prod-data-tte/repos/scala/release/com/micron/pesoft/tteq-2.3.0.jar"],\
                external_package = "google-cloud-storage==1.38.0 pyspark==3.0.1 git+https://bitbucket.micron.com/bbdc/scm/bd_at/tte_index_api.git")
            Cluster creation.. 
            test-cluster-data-reader - RUNNING
            test-cluster not  available in dataproc
        """

        # Create the cluster config.
        try:
            #external_package="google-cloud-storage==1.38.0 pyspark==3.0.1 git+https://bitbucket.micron.com/bbdc/scm/bd_at/tte_index_api.git"
            # spark_jars="gs://gdw-prod-data-probe-lib/spark-probe-trevni-3.1.1-DEV.jar,gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar,gs://gdw-prod-data-tte/repos/scala/release/com/micron/pesoft/tteq-2.3.0.jar"
            if config_bucket_name == '':
                config_bucket_name = self.project_id + "-default"
            if(isinstance(external_package, list)):
                external_package = " ".join(external_package)
            elif(isinstance(external_package, str)):
                external_package = external_package
                #"google-cloud-storage==1.38.0 pyspark==3.0.1"
                #external_package = "google-cloud-storage==1.38.0 pyspark==3.0.1 git+https://bitbucket.micron.com/bbdc/scm/bd_at/tte_index_api.git"

            if(isinstance(spark_jars, list)):
                spark_jars = ",".join(spark_jars)
            elif(isinstance(spark_jars, str)):
                spark_jars = spark_jars
                #spark_jars = "gs://gdw-prod-data-probe-lib/spark-probe-trevni-3.1.1-DEV.jar,gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar,gs://gdw-prod-data-tte/repos/scala/release/com/micron/pesoft/tteq-2.3.0.jar"

            print("Cluster creation.. ")
            cluster = {
                "project_id": self.project_id,
                "cluster_name": self.cluster_name,
                "config": {
                    "master_config": {"num_instances": 1, "machine_type_uri": master_machine_type},
                    "worker_config": {"num_instances": num_of_workers, "machine_type_uri": worker_machine_type},
                    "software_config": {"image_version": image_version,
                                        "optional_components": ['JUPYTER'],
                                        "properties": {
                                            "spark: spark.jars": spark_jars,
                                            "spark:spark.jars.repositories": spark_jar_repos,
                                            "spark: spark.jars.packages": spark_jars_packages,
                                            "dataproc:dataproc.logging.stackdriver.job.driver.enable": "true",
                                            "dataproc:dataproc.logging.stackdriver.job.yarn.container.enable": "true"
                                        }
                                        },
                    "initialization_actions": [
                        {"executable_file": 'gs://gdw-shared-resources/dataproc/initialization_actions/component-gateway-vpc-sc-dns-init-action-and-ssl-install.sh'},
                        {"executable_file": 'gs://goog-dataproc-initialization-actions-us-west1/python/pip-install.sh'}
                    ],
                    "gce_cluster_config": {
                        "subnetwork_uri": "projects/shared-vpc-271916/regions/us-west1/subnetworks/sub-us-west1-gdw-dev-test",
                        "service_account": "shared-service-account@" + self.project_id + ".iam.gserviceaccount.com",
                        "metadata": {"PIP_PACKAGES": external_package},
                        "internal_ip_only": True},

                    "endpoint_config": {"enable_http_port_access": True},
                    "config_bucket": config_bucket_name
                },
            }

            if autoscale_policy != '':
                cluster['config']['autoscaling_config'] = {"policy_uri": f"projects/{self.project_id}/regions/us-west1/autoscalingPolicies/{autoscale_policy}"}

            # Create the cluster.
            global waiting_callback
            if self.check_availability(self.cluster_name):
                operation = self.cluster_client.create_cluster(request={"project_id": self.project_id,
                                                                        "region": self.region,
                                                                        "cluster": cluster})
                operation.add_done_callback(self.callback)
                waiting_callback = True
                return operation
            else:
                waiting_callback = False
                print("Cluster with the specified name  is already present in the project.")
        except:
            traceback.print_exc()

    def delete_cluster(self):
        """Delete the cluster.

        Returns:
            (google.api_core.operation_async.AsyncOperation): Operation object corresponding to Delete Cluster operation

        Example:
            >>> op = obj.delete_cluster()
            lastupdated-time-testing - RUNNING
            test-1 - RUNNING
            test-cluster - RUNNING
            test-cluster is available in dataproc
            test-cluster-data-reader - RUNNING
            Tearing down cluster.
        """
        try:
            global waiting_callback
            if not self.check_availability(self.cluster_name):
                print("Tearing down cluster.")
                result = self.cluster_client.delete_cluster(request={"project_id": self.project_id,
                                                                    "region": self.region,
                                                                    "cluster_name": self.cluster_name})
                result.add_done_callback(self.callback)
                waiting_callback = True
                return result
            print("Unable to delete, Cluster doesn't exist.")
            waiting_callback = False
        except:
            traceback.print_exc()

    def submit_pyspark_job(self, main_python_file,
                           config_file, pythonfiles,
                           args_list):
        """Submit a pyspark job on the created cluster using SubmitJob API. Should be called only after cluster creation

        Args:
            main_python_file(str): URI of python file to be used as driver.
            config_file([str]): URI of config files containing parameters used by the main python file
            pythonfiles([str]): URIs of python files to be passed to the spark framework(.egg,.zip,.py)
            args_list([str]): Optional arguments to be passed to the Driver program.

        Returns:
            (int): ID of newly created job.

        Example:
            >>> main_python_file = "gs://us-west2-gdw-dev-smai-vtctr-5610cc03-bucket/dags/dist/preprocessing_main.py"
            >>> config_file_uris = ["gs://us-west2-gdw-dev-smai-vtctr-5610cc03-bucket/dags/dist/config_monitoring.yml"]
            >>> python_file_uris = ["gs://us-west2-gdw-dev-smai-vtctr-5610cc03-bucket/dags/dist/src.zip"]
            >>> args_list = ['manual',"DESIGN_ID ='Z41C' and PROCESS_ID in ('RPP')  and end_datetime>'2022-02-08T00:00:00' and  end_datetime<='2022-02-08T11:59:59'", "22-02-2022 123456789", "22-02-2022"]
            >>> job_id = cluster_object.submit_pyspark_job(main_python_file, config_file_uris, python_file_uris, args_list)
        """
        try:
            job = {"placement": {"cluster_name": self.cluster_name},
                   "pyspark_job": {
                "main_python_file_uri": main_python_file,
                "file_uris": config_file,
                "python_file_uris": pythonfiles,
                "jar_file_uris": ["gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar", "gs://gdw-prod-data-probe-lib/spark-probe-trevni-3.1.1-SNAPSHOT.jar"],
                "args": args_list,
            }
            }

            result = self.job_client.submit_job_as_operation(request={"project_id": self.project_id,
                                                                      "region": self.region,
                                                                      "job": job})
            response = result.result()
            job_id = response.reference.job_id
            print("Submitted job ID {}.".format(job_id))
            return job_id
        except:
            traceback.print_exc()

    def update_cluster(self, project_id, region, cluster_name, new_num_instances):
        """Update the number of workers in the existing cluster

        Args:
            project_id (str): Project to use for creating resources.
            region (str): Region where the resources should live.
            cluster_name (str): Name to use for creating a cluster.
            new_num_instances: Number of worker nodes in the updated cluster

        Example:
            >>> obj.update_cluster("gdw-dev-smai-vtctrimopt", "us-west1", "test-rj", 2)
            Cluster was updated successfully: test-rj
        """
        try:
            # Get cluster you wish to update.
            cluster = self.cluster_client.get_cluster(project_id=project_id, region=region, cluster_name=cluster_name)

            # Update number of clusters
            mask = {"paths": {"config.worker_config.num_instances": str(new_num_instances)}}

            # Update cluster config
            cluster.config.worker_config.num_instances = new_num_instances

            # Update cluster
            operation = self.cluster_client.update_cluster(
                project_id=self.project_id,
                region=self.region,
                cluster=cluster,
                cluster_name=self.cluster_name,
                update_mask=mask,
            )

            # Output a success message.
            updated_cluster = operation.result()
            print(f"Cluster was updated successfully: {updated_cluster.cluster_name}")
        except:
            traceback.print_exc()

    def wait_for_job(self, job_id):
        """Check status of job with specified job ID.

        Args:
            job_id: Job ID corresponding to the job whose status is to be checked.

        Returns:
            job object corresponding to the job.

        Example:
            >>> job_id = cluster_object.submit_pyspark_job(main_python_file, config_file_uris, python_file_uris, args_list)
            >>> job = cluster_obj.wait_for_job(job_id)
        """
        try:
            print("Waiting for job to finish...")
            while True:
                job = self.job_client.get_job(request={"project_id": self.project_id,
                                                       "region": self.region,
                                                       "job_id": job_id})
                print(job.status)
                return job
        except:
            traceback.print_exc()

    def get_cluster_id_by_name(self, cluster_name):
        """Get the cluster UUID of the cluster corresponding to given cluster name in the current project. 

        Args:
            cluster_name(str): name of the cluster whose ID is to be retrieved.

        Returns:
            (str,str): Cluster UUID(Universal Unique Identifier) and the Cloud Storage bucket used to stage job dependencies, config files, and job driver console output.

        Example:
            >>> obj.get_cluster_id_by_name("test-rj")
            ('1e1722c7-9493-4aea-a5a2-9cc6e6fd2467',
            'dataproc-staging-us-west1-409236589846-unre4ap8')

            >>> obj.get_cluster_id_by_name("testing-framework-new")
            ('d8314c81-577f-4950-8362-8cae7a87b77a',
            'dataproc-staging-us-west1-409236589846-unre4ap8')

        """
        try:
            for cluster in self.cluster_client.list_clusters(request={"project_id": self.project_id,
                                                                      "region": self.region}):
                if cluster.cluster_name == cluster_name:
                    return cluster.cluster_uuid, cluster.config.config_bucket
        except:
            traceback.print_exc()

    def check_availability(self, cluster_name):
        """Check the availability of given cluster name in the current project

        Args:
            cluster_name (str): Cluster Name to be checked for availability.

        Returns:
            int:
                0 if the cluster with specified cluster name exists
                1 if the cluster doesn't exist

        Example:
            >>> availability = obj.check_availability("test-rj")
            test-cluster - RUNNING
            test-rj - RUNNING
            test-rj is available in dataproc
            testing-framework-123 - RUNNING
            testing-framework-new - RUNNING

            >>> availability = obj.check_availability("test-frmwrk")
            test-rj - RUNNING
            testing-framework-123 - RUNNING
            testing-framework-new - RUNNING
            test-frmwrk not  available in dataproc
        """
        try:
            cluster_list = [cluster for cluster in
                            self.cluster_client.list_clusters(request={"project_id": self.project_id,
                                                                       "region": self.region})]
            if len(cluster_list) == 0:
                print(f"{cluster_name} not  available in dataproc")
                return 1
            else:
                availability = False
                for cluster in cluster_list:
                    #print(("{} - {}".format(cluster.cluster_name, cluster.status.state.name, )))
                    if (cluster.cluster_name == cluster_name):
                        print(f"{cluster_name} is available in dataproc")
                        availability = True
                if availability:
                    return 0
                else:
                    print(f"{cluster_name} not  available in dataproc")
                    return 1
        except:
            traceback.print_exc()

    def list_clusters_with_details(self):
        """List the name and status of clusters in the region.

        Example:
            >>> obj.list_clusters_with_details()
            test-cluster - RUNNING
            test-rj - RUNNING
            testing-framework-123 - RUNNING
            testing-framework-new - RUNNING
        """
        try:
            cluster_list = [cluster for cluster in
                            self.cluster_client.list_clusters(request={"project_id": self.project_id,
                                                                       "region": self.region})]
            if len(cluster_list) == 0:
                print("Cluster are not present")
            else:
                for cluster in cluster_list:
                    print(("{} - {}".format(cluster.cluster_name, cluster.status.state.name, )))
        except:
            traceback.print_exc()

    def callback(self, operation_future):
        # Reset global when callback returns.
        global waiting_callback
        waiting_callback = False

    def wait_for_cluster_creation(self):
        """Wait for cluster creation;Use after call to create_cluster method.

        Example:
            >>> op = obj.create_cluster(cluster_params)
            >>> obj.wait_for_cluster_creation()
            Waiting for cluster creation...
            Cluster created.
        """
        if waiting_callback:
            print("Waiting for cluster creation...")
            while True:
                if not waiting_callback:
                    print("Cluster created.")
                    break
        else:
            print("No creation process is pending.")

    def wait_for_cluster_deletion(self):
        """Wait for cluster deletion;Use after call to delete_cluster method.

        Example:
            >>> op = obj.delete_cluster(cluster_params)
            >>> obj.wait_for_cluster_deletion()
            Waiting for cluster deletion...
            Cluster deleted.
        """
        if waiting_callback:
            print("Waiting for cluster deletion...")
            while True:
                if not waiting_callback:
                    print("Cluster deleted.")
                    break
        else:
            print("No deletion process is pending.")
