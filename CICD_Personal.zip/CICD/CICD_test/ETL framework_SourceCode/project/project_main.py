from Data_reader.data_reader import spark_reader
from Transformation.transformation import spark_operations
from Data_writer.data_writer import spark_writer
from Spark_initialization.spark_initialization import start_spark
from Bigquery.bigquery_ddl import *
from Logger.logger import get_logger

def main():
    spark_session = start_spark(app_name="test", master='yarn')
    l = get_logger('test',"../test_log.txt")
    obj = DDL("gdw-dev-smai-vtctrimopt")
    obj.create_dataset("Framework_test")
    fields = ["FID", "START_LOT_KEY", "WAFER_SCRIBE", "DESIGN_ID", "START_DATETIME"]
    query = ["DESIGN_ID='Z41C'", "PROCESS_ID in ('RPP')", "fab='16'","start_datetime>'2021-09-03'", "end_datetime<'2021-09-05'"]
    df_trevni2 = spark_reader("trevni2", spark_session, fields=fields, query=query)
    l.info("Data is read from trevni")
    df = spark_operations(df_trevni2,"drop_duplicates") 
    l.info("Transformation is completed")
    spark_writer('bigquery',df,mode_type='overwrite',project_bucketname='gdw-dev-smai-vtctrimopt-default',tablename='Framework_test.test_table')
    l.info("Written into bigquery")
    
main()