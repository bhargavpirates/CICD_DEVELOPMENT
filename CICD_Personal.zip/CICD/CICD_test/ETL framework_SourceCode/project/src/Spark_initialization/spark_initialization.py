from configparser import ConfigParser
import traceback
import sys

from pyspark.sql import SparkSession

def start_spark(app_name='provide-valid-application-name',  master="yarn", jar_packages=None, files=None, config=None, enableHiveSupport=False):
    """creates SparkSession

    Args:
        app_name(str): Used to set your application name 
        master(str): If you are running it on the cluster you need to use your master name as an argument to master().
            usually, it would be either yarn or mesos depends on your cluster setup. It can be local if it run on standalone system
        jar_packages(str/[str]): list of jar packages
        files(str/[str]): SaveMode, that specifies how to handle existing data if present.
        config(dict/[[str,str]]/[[str,Boolean]]/[[str,double]]/[[str,long]]): Sets a config option.
        enableHiveSupport(Boolean): If true, enables Hive support, including connectivity to a persistent Hive metastore, 
            support for Hive serdes, and Hive user-defined functions.
    
    Returns:
        pyspark.sql.SparkSession: SparkSession according to the given configuration

    >>> start_spark(app_name='spark-Transformation-logic',  master="local", jar_packages=None, files=None, config=None, enableHiveSupport=False)
    """   
    try:
        spark_builder = SparkSession.builder.master(master).appName(app_name)

        if(isinstance(jar_packages, list)):
            for jar in jar_packages:
                spark_builder.config('spark.jars.packages', jar)
        elif (isinstance(jar_packages, str)):
            jar_packages=jar_packages.split(",")
            for jar in jar_packages:
                spark_builder.config('spark.jars.packages', jar)

        if(isinstance(files, list)):
            for file in files:
                spark_builder.config('spark.files', file)
        elif (isinstance(files, str)):
            files=files.split(",")
            for file in files:
                spark_builder.config('spark.files', file)

        #   add other config params
        if(isinstance(config, dict)):
            for k,v in config.items():
                print(k, v)
                spark_builder.config(k, v)
        elif (isinstance(config, list)):
            # print("&"*100)
            for k, v in config:
                spark_builder.config(k, v)

        if(enableHiveSupport):
            spark_builder.enableHiveSupport()

        spark_sess = spark_builder.getOrCreate()

        return spark_sess
    except:
        traceback.print_exc()
        print("Failed to initialize spark session")
        

# if __name__ == "__main__":
#     print(start_spark())
