# from spark_initialization import start_spark
# from pyspark.sql import Row
from pyspark.sql.functions import col
from time import time
from functools import reduce
from functools import wraps
import traceback
import sys


# spark=start_spark(app_name='spark-Transformation-logic',  master="local", jar_packages=None, files=None, config=None, enableHiveSupport=False)


def drop_duplicates(df, **kwargs):
    """returns DataFrame after droping duplicate records

    Args:
        df(pyspark.sql.dataframe.DataFrame): DataFrame to be modified
        **columns(str/[str]): duplicate rows removed, only considering certain column or list of columns 
            given as string or list.

    Returns:
        pyspark.sql.dataframe.DataFrame: DataFrame after droping duplicate records
    """  
    try:
        if 'columns' in kwargs.keys():
            if(isinstance(kwargs['columns'], list)):
                return df.dropDuplicates(kwargs['columns'])    
            else:
                return df.dropDuplicates(kwargs['columns'].split(','))
        else:
            return df.dropDuplicates()
    except:
        traceback.print_exc()
        

def drop_columns(df, **kwargs):
    """returns DataFrame after droping columns

    Args:
        df(pyspark.sql.dataframe.DataFrame): DataFrame to be modified
        **columns([str]): list of columns which need to be dropped
        **starts_with(str): drops columns whose names start with the given value in starts_with
        **ends_with(str): drops columns whose names ends with the given value in ends_with
        **contains(str): drops columns whose names contains given value in contains

    Returns:
        pyspark.sql.dataframe.DataFrame: DataFrame after droping columns
    """  
    try:
        if('columns' in kwargs.keys()):
            if(isinstance(kwargs['columns'], list)):
                return df.drop(*kwargs['columns'])
        elif('starts_with' in kwargs.keys()):
            columns_created = [i for i in df.columns if i.startswith(kwargs['starts_with'])]
            return df.drop(*columns_created)
        elif ('ends_with' in kwargs.keys()):
            columns_created = [i for i in df.columns if i.endswith(kwargs['ends_with'])]
            return df.drop(*columns_created)
        elif ('contains' in kwargs.keys()):
            columnsDrop = [i for i in df.columns if i.__contains__(kwargs['contains'])]
            return df.drop(*columnsDrop)
        else:
            print("Specify Drop critirea")
    except:
        traceback.print_exc()
        

def drop_nulls(df, **kwargs):
    """returns DataFrame after droping null values

    Args:
        df(pyspark.sql.dataframe.DataFrame): DataFrame to be modified
        **columns(str): can be 'any','all','subset'. If 'any,' records are dropped if the value is null in any column.
            If 'all', records are dropped if the value is null in all column. If 'subset', records are dropped if the 
            value is null in all columns in columns_subset.
        **columns_subset([str]): If columns='subset', records are dropped if the value is null in all columns in columns_subset.

    Returns:
        pyspark.sql.dataframe.DataFrame: DataFrame after droping null values
    """  
    try:
        if('columns' in kwargs.keys()):
            if(kwargs['columns'].lower()=="any"):
                return df.na.drop() #same as df.na.drop("any") default is "any"
            elif(kwargs['columns'].lower() == "all"):
                return df.na.drop("all")
            elif(kwargs['columns'] == "subset"):
                if('columns_subset' in kwargs.keys()):
                    return df.na.drop('all', subset=kwargs['columns_subset'])
                else:
                    print("please provide columns_subset list")
    except:
        traceback.print_exc()
        

def filter_(df, **kwargs):
    """returns DataFrame after filtering

    Args:
        df(pyspark.sql.dataframe.DataFrame): DataFrame to be modified
        **sql(str): a statement(sql expression) giving the condition
        **programatic(str): Columns with a condition

    Returns:
        pyspark.sql.dataframe.DataFrame: DataFrame after filtering
    """  
    try:
        if('sql' in kwargs.keys()):
            #df.filter("name in ('Bhargav','Alice') and height between 80 and 100 ").show()
            return df.filter(kwargs['sql'])
        elif('programatic' in kwargs.keys()):
            return df.filter(kwargs['programatic'])
    except:
        traceback.print_exc()
        

def replace_values(df, **kwargs):
    """Replace a value in the dataframe with the given values.

    Args:
        df (pyspark.sql.dataframe.DataFrame): The dataframe whose values are to be replaced.
        replace_set ([any,any,[str]]): List consisting of the value to replace, new value and columns to be considered.

    Returns:
        (pyspark.sql.dataframe.DataFrame): Dataframe with updated values.

    """
    try:
        #**kwargs == [replace_type = null,  [(),
        if(kwargs['replace_set'][0]=="null"):
            #[null,0,columns]
            return df.fillna(value=kwargs['replace_set'][1], subset=kwargs['replace_set'][2])
        elif(kwargs['replace_set'][0]!="null"):
            #df.replace([72, 5], [7200, 10], ['height', 'age']).show()
            return df.replace(kwargs['replace_set'][0], value=kwargs['replace_set'][1], subset=kwargs['replace_set'][2])
    except:
        traceback.print_exc()
        

##def replace(df, **kwargs):
##    #**kwargs == [replace_type = null,  [(),
##    if(kwargs['replace_set'][0]=="null" and isinstance(kwargs['replace_set'][1],str) ):
##        #[null,0,columns]
##        df.fillna(value=kwargs['replace_set'][1], subset=kwargs['replace_set'][2])
##    elif(kwargs['replace_set'][0]!="null"):
##        #df.replace([72, 5], [7200, 10], ['height', 'age']).show()
##        df.replace(kwargs['replace_set'][0], value=kwargs['replace_set'][1], subset=kwargs['replace_set'][2])


def column_name_alias(df, **kwargs):
    """Update names of specified columns:

    Args:
        df (pyspark.sql.dataframe.DataFrame): The dataframe whose column names are to be updated.
        oldColumns([str]): List of column names whose names should be updated.
        newColumns([str]): List containing new names of corresponding column in oldColumns list.

    Returns:
        (pyspark.sql.dataframe.DataFrame,[str]): tuple consisting of updated dataframe and list of renamed columns.

    """
    try:
        oldColumns = kwargs['old_columns']
        newColumns = kwargs['new_columns']
        df_ = reduce(lambda df, idx: df.withColumnRenamed(oldColumns[idx], newColumns[idx]), range(len(oldColumns)), df)
        return df_, newColumns
    except:
        traceback.print_exc()
        


def check_duplicate(df, action="", **kwargs):
    """Check if duplicate exists or get number of duplicate.

    Args:
        df (pyspark.sql.dataframe.DataFrame): The dataframe which is to checked for duplicates.
        action (str): Specify whether to count duplicates or just check of existence of duplicates.
        columns ([str], optional): Specify which columns to consider when checking for duplicates. If not specified, all columns will be considered.

    """
    try:
        if(action=="duplicate_exists"):
            if(df.exceptAll(drop_duplicates(df, **kwargs)).first()):
                print("Duplicates exist")
            else:
                print("No Duplicates")
        elif(action == "duplicate_count"):
            print("Duplicate Count:"+ str(df.exceptAll(drop_duplicates(df, **kwargs)).count()))
    except:
        traceback.print_exc()
        

def type_conversion(df, **kwargs):
    #type_change = {"float":[],"int":[]}
    """Change type of specified columns.

    Args:
        df (pyspark.sql.dataframe.DataFrame): The dataframe which whose column types are to be updated.
        type_change (dict): Keys are strings specifying target types of the column specified in their corresponding lists.

    Returns:
        (pyspark.sql.dataframe.DataFrame): Dataframe with updated columns types.
    """
    try:
        res=[]
        for datatype,columnnames in kwargs['type_change'].items():
            res = res + [col(c).cast(datatype).alias(c) for c in columnnames]
        typeconversion_columns=[j for i in kwargs['type_change'].values() for j in i]
        total_columns=df.columns
        remaining_columns=set(total_columns)-set(typeconversion_columns)
        return df.select(*remaining_columns, *res).select(*total_columns)
    except:
        traceback.print_exc()
        

def spark_operations(df,action="", **kwargs):
    """
    perfrom transformations on DataFrame
    
    Args:
        df(pyspark.sql.dataframe.DataFrame): DataFrame to be modified
        action(str): 
        
            | "drop_duplicates": drops duplicate records
            | "drop_columns": to drop specifies columns
            | "drop_nulls": to drop nulls
            | "filter": to filter the dataframe
            | "replace": Replace a value in the dataframe with the given values.
            | "column_rename": Update names of specified columns
            | "duplicate_exists": Check if duplicate exists
            | "duplicate_count": get number of duplicate.
            | "type_conversion": Change type of specified columns.

        **columns(str/[str]): For action="drop_nulls" columns can be 'any','all','subset'. 
            If 'any', records are dropped if the value is null in any column. 
            If 'all', records are dropped if the value is null in all column. 
            If 'subset', records are dropped if the value is null in all columns in columns_subset.
            For other actions refer to examples.
        **oldColumn([str]): List of column names whose names should be updated for action="column_rename".
        **newColumns([str]): List containing new names of corresponding column in oldColumns list for action="column_rename".
        **starts_with (str): drops columns whose names start with the given value in starts_with for action="drop_columns"
        **ends_with(str): drops columns whose names ends with the given value in ends_with for action="drop_columns"
        **contains(str): drops columns whose names contains given value in contains for action="drop_columns"
        **columns_subset([str]): If columns='subset', records are dropped if the value is null in all columns in columns_subset.
        **sql(str): a statement(sql expression) giving the condition for action="filter"
        **programatic(str): Columns with a condition for action="filter"
        **replace_set([any,any,[str]]): List consisting of the value to replace, new value and columns to be considered for action="replace"
        **type_change (dict): Keys are strings specifying target types of the column specified in their corresponding lists for action="type_conversion"
    In examples df and df_n are taken and transformations are made on top of them.

    >>> df.show()
    +-------+---+------+
    |   name|age|height|
    +-------+---+------+
    |  Alice|  5|    80|
    |  Alice|  5|    80|
    |  Alice| 10|    80|
    |  Alice| 10|    95|
    |  Arrya| 20|    60|
    |Bhargav| 30|    80|
    |    cat| 40|    80|
    |   caat| 50|    40|
    |    DOG| 20|    50|
    | Donkey| 30|   100|
    |    eat| 40|   105|
    |  pavan| 50|    85|
    | suresh| 69|    94|
    |  varun| 70|    99|
    |    sun| 90|    72|
    +-------+---+------+
    >>> df_n.show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|    60|
    |Bhargav|  30|    80|
    |    cat|null|    80|
    |   caat|  50|    40|
    |   null|  20|    50|
    | Donkey|  30|   100|
    |    eat|  40|  null|
    |  pavan|  50|    85|
    | suresh|  69|    94|
    |  varun|null|    99|
    |   null|null|  null|
    |   null|null|     2|
    |    sun|  90|    72|
    +-------+----+------+

    For action='drop_duplicates': Return a new DataFrame with duplicate rows removed, optionally only considering certain columns.

    >>> df1 = spark_operations(df,'drop_duplicates')
    >>> df1.show()
    +-------+---+------+
    |   name|age|height|
    +-------+---+------+
    |Bhargav| 30|    80|
    |  Arrya| 20|    60|
    |  Alice| 10|    95|
    |    DOG| 20|    50|
    |    sun| 90|    72|
    |  pavan| 50|    85|
    |  Alice|  5|    80|
    |  Alice| 10|    80|
    |   caat| 50|    40|
    |    cat| 40|    80|
    | Donkey| 30|   100|
    |  varun| 70|    99|
    | suresh| 69|    94|
    |    eat| 40|   105|
    +-------+---+------+
    >>> df2 = spark_operations(df,'drop_duplicates',columns=["name"])
    >>> df2.show()
    +-------+---+------+
    |   name|age|height|
    +-------+---+------+
    |  Arrya| 20|    60|
    |    DOG| 20|    50|
    |    cat| 40|    80|
    |    eat| 40|   105|
    | suresh| 69|    94|
    |  varun| 70|    99|
    |  Alice|  5|    80|
    |Bhargav| 30|    80|
    |   caat| 50|    40|
    | Donkey| 30|   100|
    |    sun| 90|    72|
    |  pavan| 50|    85|
    +-------+---+------+

    For action='drop_columns': drops the columns provided in list format or drops columns whose names start with the given value in starts_with
    or drops columns whose names ends with the given value in ends_with or drops columns whose names contains given value in contains

    >>> df3 = spark_operations(df,'drop_columns',columns = ['name'])
    >>> df3.show()
    +---+------+
    |age|height|
    +---+------+
    |  5|    80|
    |  5|    80|
    | 10|    80|
    | 10|    95|
    | 20|    60|
    | 30|    80|
    | 40|    80|
    | 50|    40|
    | 20|    50|
    | 30|   100|
    | 40|   105|
    | 50|    85|
    | 69|    94|
    | 70|    99|
    | 90|    72|
    +---+------+
    >>> df4 = spark_operations(df,'drop_columns',starts_with = 'ag')
    >>> df4.show()
    +-------+------+
    |   name|height|
    +-------+------+
    |  Alice|    80|
    |  Alice|    80|
    |  Alice|    80|
    |  Alice|    95|
    |  Arrya|    60|
    |Bhargav|    80|
    |    cat|    80|
    |   caat|    40|
    |    DOG|    50|
    | Donkey|   100|
    |    eat|   105|
    |  pavan|    85|
    | suresh|    94|
    |  varun|    99|
    |    sun|    72|
    +-------+------+
    >>> df5 = spark_operations(df,'drop_columns',ends_with = 'e')
    >>> df5.show()
    +------+
    |height|
    +------+
    |    80|
    |    80|
    |    80|
    |    95|
    |    60|
    |    80|
    |    80|
    |    40|
    |    50|
    |   100|
    |   105|
    |    85|
    |    94|
    |    99|
    |    72|
    +------+
    >>> df6 = spark_operations(df,'drop_columns',contains = 'ei')
    >>> df6.show()
    +-------+---+
    |   name|age|
    +-------+---+
    |  Alice|  5|
    |  Alice|  5|
    |  Alice| 10|
    |  Alice| 10|
    |  Arrya| 20|
    |Bhargav| 30|
    |    cat| 40|
    |   caat| 50|
    |    DOG| 20|
    | Donkey| 30|
    |    eat| 40|
    |  pavan| 50|
    | suresh| 69|
    |  varun| 70|
    |    sun| 90|
    +-------+---+

    For action='drop_nulls': If columns is specified as 'any'- it drops records when any of the columns contain null. If column 
    is specified as 'all', it drops records when all of the columns contain null. If column is specified as 'subset' then a 
    list of columns to be given to columns_subset, it drops records when all of the columns in column_subset contain null

    >>> df7 = spark_operations(df_n,'drop_nulls',columns='any') 
    >>> df7.show()
    +-------+---+------+
    |   name|age|height|
    +-------+---+------+
    |  Alice|  5|    80|
    |  Alice|  5|    80|
    |  Alice| 10|    80|
    |  Alice| 10|    95|
    |  Arrya| 20|    60|
    |Bhargav| 30|    80|
    |   caat| 50|    40|
    | Donkey| 30|   100|
    |  pavan| 50|    85|
    | suresh| 69|    94|
    |    sun| 90|    72|
    +-------+---+------+
    >>> df8 = spark_operations(df_n,'drop_nulls',columns='all') 
    >>> df8.show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|    60|
    |Bhargav|  30|    80|
    |    cat|null|    80|
    |   caat|  50|    40|
    |   null|  20|    50|
    | Donkey|  30|   100|
    |    eat|  40|  null|
    |  pavan|  50|    85|
    | suresh|  69|    94|
    |  varun|null|    99|
    |    sun|  90|    72|
    +-------+----+------+
    >>> df9 = spark_operations(df_n,'drop_nulls',columns='subset',columns_subset=['name','age']) 
    >>> df9.show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|    60|
    |Bhargav|  30|    80|
    |    cat|null|    80|
    |   caat|  50|    40|
    |   null|  20|    50|
    | Donkey|  30|   100|
    |    eat|  40|  null|
    |  pavan|  50|    85|
    | suresh|  69|    94|
    |  varun|null|    99|
    |    sun|  90|    72|
    +-------+----+------+

    For action='filter': Returns modified DataFrame based on a sql expression given in sql or columns with condition in programatic

    >>> df10 = spark_operations(df,"filter",sql="name in ('pavan','caat') and age >30")
    >>> df10.show()
    +-----+---+------+
    | name|age|height|
    +-----+---+------+
    | caat| 50|    40|
    |pavan| 50|    85|
    +-----+---+------+
    >>> df11 = spark_operations(df,"filter",programatic= ((df.name == 'pavan') | (df.name == 'cat') & (df.age >30) ))
    >>> df11.show()
    +-----+---+------+
    | name|age|height|
    +-----+---+------+
    |  cat| 40|    80|
    |pavan| 50|    85|
    +-----+---+------+

    All action specified below are performed on this DataFrame.

    >>> df.show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|  null|
    |Bhargav|  30|    80|
    |    cat|  40|    80|
    |   null|  50|    40|
    |    DOG|  20|    50|
    | Donkey|  30|   100|
    |    eat|null|   105|
    |  pavan|  50|    85|
    | suresh|  69|    94|
    |  varun|  70|    99|
    |   null|null|  null|
    |    sun|  90|    72|
    +-------+----+------+

    For action='replace': Returns modified DataFrame with the value specified in index 0 in replace_set gets replaced by value in index 1 for the columns specified in index 3.

    >>> spark_operations(df, "replace", replace_set=["null", 0, ['height']]).show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|     0|
    |Bhargav|  30|    80|
    |    cat|  40|    80|
    |   null|  50|    40|
    |    DOG|  20|    50|
    | Donkey|  30|   100|
    |    eat|null|   105|
    |  pavan|  50|    85|
    | suresh|  69|    94|
    |  varun|  70|    99|
    |   null|null|     0|
    |    sun|  90|    72|
    +-------+----+------+
    >>> spark_operations(df, "replace", replace_set=[50, 5, ['height','age']]).show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|  null|
    |Bhargav|  30|    80|
    |    cat|  40|    80|
    |   null|   5|    40|
    |    DOG|  20|     5|
    | Donkey|  30|   100|
    |    eat|null|   105|
    |  pavan|   5|    85|
    | suresh|  69|    94|
    |  varun|  70|    99|
    |   null|null|  null|
    |    sun|  90|    72|
    +-------+----+------+

    For action='column_rename': Returns modified DataFrame with each column in old_columns renamed to its corresponding entry in new_columns.

    >>> spark_operations(df, "column_rename", old_columns=['name','age'] , new_columns=['Name','Age'])[0].show()
    +-------+----+------+
    |   Name| Age|height|
    +-------+----+------+
    |  Alice|   5|    80|
    |  Alice|   5|    80|
    |  Alice|  10|    80|
    |  Alice|  10|    95|
    |  Arrya|  20|  null|
    |Bhargav|  30|    80|
    |    cat|  40|    80|
    |   null|  50|    40|
    |    DOG|  20|    50|
    | Donkey|  30|   100|
    |    eat|null|   105|
    |  pavan|  50|    85|
    | suresh|  69|    94|
    |  varun|  70|    99|
    |   null|null|  null|
    |    sun|  90|    72|
    +-------+----+------+

    For action='duplicate_exists': Prints out whether duplicate entries exists or not only considering the columns specified in through columns argument.

    >>> spark_operations(df, "duplicate_exists", columns='name')
    Duplicates exist

    For action='duplicate_count': Prints out the number of duplicate entries considering the subset of rows specified through columns argument.

    >>> spark_operations(df, "duplicate_count", columns=['name','age'])
    Duplicate Count:2

    For action='type_change': Changes the type of columns to type specified in key for each column in the corresponding pair value.
    
    >>> df
    DataFrame[name: string, age: bigint, height: bigint]
    >>> spark_operations(df, 'type_conversion', type_change={"int":['height'], "float":['age']})
    DataFrame[name: string, age: float, height: int]
    >>> df.show()
    +-------+----+------+
    |   name| age|height|
    +-------+----+------+
    |  Alice| 5.0|    80|
    |  Alice| 5.0|    80|
    |  Alice|10.0|    80|
    |  Alice|10.0|    95|
    |  Arrya|20.0|  null|
    |Bhargav|30.0|    80|
    |    cat|40.0|    80|
    |   null|50.0|    40|
    |    DOG|20.0|    50|
    | Donkey|30.0|   100|
    |    eat|null|   105|
    |  pavan|50.0|    85|
    | suresh|69.0|    94|
    |  varun|70.0|    99|
    |   null|null|  null|
    |    sun|90.0|    72|
    +-------+----+------+
    """
    try:
        if(action=="drop_duplicates"):
            return drop_duplicates(df, **kwargs)
        elif(action=='drop_columns'):
            return drop_columns(df, **kwargs)
        elif(action=='drop_nulls'):
            return drop_nulls(df, **kwargs)
        elif(action=='filter'):
            return filter_(df, **kwargs)
        elif(action=='replace'):
            return replace_values(df, **kwargs)
        elif(action=='column_rename'):
            return column_name_alias(df, **kwargs)
        elif(action.startswith("duplicate")):
            return check_duplicate(df, action, **kwargs)
        elif(action == "type_conversion"):
            return type_conversion(df, **kwargs)
    except:
        traceback.print_exc()
        


##def spark_operations(df,action="", **kwargs):
##    if(action=="drop_duplicates"):
##        return drop_duplicates(df, **kwargs)
##    elif(action=='drop_columns'):
##        return drop_columns(df, **kwargs)
##    elif(action=='drop_nulls'):
##        return drop_columns(df, **kwargs)
##    elif(action=='filter'):
##        return drop_columns(df, **kwargs)
##    elif(action=='replace'):
##        return replace_vales(df, **kwargs)
##    elif(action=='column_rename'):
##        return replace_vales(df, **kwargs)
##    elif(action=='column_rename'):
##        return column_name_alias(df, **kwargs)



#def filter(df, **kwargs):
#    df.filter(~col('bar').isin(['a', 'b'])).show()
#    df.filter(col('bar').isin(['a', 'b']) == False).show()
#    df.filter((df.bar != 'a') & (df.bar != 'b'))
#    df.filter(df.age > 3).collect()
#    df.where(df.age == 2).collect()
#    df.filter("Add = 'USA' and Name = 'Jhn'").show()
#
#
#def replace_vales(df):
#    df.fillna(value=0).show()
#    df.fillna(value=0, subset=["population"]).show()
#    df.na.fill(value=0).show()
#    df.na.fill(value=0, subset=["population"]).show()
#
#    df.fillna(value="").show()
#    df.na.fill(value="").show()
#
#    df.fillna("unknown", ["city"]) \
#        .fillna("", ["type"]).show()
#
#    df.fillna({"city": "unknown", "type": ""}) \
#        .show()
#
#    df.na.fill("unknown", ["city"]).na.fill("", ["type"]).show()
#
#    from pyspark.sql.functions import *
#    newDf = df.withColumn('address', regexp_replace('address', 'lane', 'ln'))
#
#    df.replace('Alice', "A").show()
#    df.replace([72, 5], [7200, 10], ['height', 'age']).show() ## subset columns must have same datatypes
#
#    df.fillna({'a': 0, 'b': 0})
#
#def join():
#    from pyspark.sql.functions import col
#
#    df1.alias('a').join(df2.alias('b'), col('b.id') == col('a.id')).select(
#        [col('a.' + xx) for xx in a.columns] + [col('b.other1'), col('b.other2')])
#
#    cr_outs = crimes.alias('a') \
#        .join(outcomes, crimes.CRIME_ID == outcomes.CRIME_ID, 'left_outer') \
#        .select(*[col('a.' + c) for c in crimes.columns]
#                 + [outcomes.FINAL_OUTCOME])
#
#    empDF.join(deptDF, empDF.emp_dept_id == deptDF.dept_id, "outer") \
#        .show(truncate=False)
#    empDF.join(deptDF, empDF.emp_dept_id == deptDF.dept_id, "full") \
#        .show(truncate=False)
#    empDF.join(deptDF, empDF.emp_dept_id == deptDF.dept_id, "fullouter") \
#        .show(truncate=False)
#
#    leftsemi, leftanti
#
#    df = df1.join(df2, (df1.A1 == df2.B1) & (df1.A2 == df2.B2))
#
#    # Join Multiple DataFrames
#    empDF.join(addDF, ["emp_id"]) \
#        .join(deptDF, empDF["emp_dept_id"] == deptDF["dept_id"]) \
#        .show()
#
#
#def aggregate():
#    # agg() function
#
#    df.groupBy("Job") \
#        .agg(f.sum("salary").alias("sum_salary"), \
#             f.avg("salary").alias("avg_salary"), \
#             f.min("salary").alias("min_salary"), \
#             f.max("salary").alias("max_salary"), \
#             f.mean("salary").alias("mean_salary") \
#             ) \
#        .show(truncate=False)
#
#    df.groupBy("Job", "Country") \
#        .avg("salary", "seniority") \
#        .show(truncate=False)
#
#    # load function
#    from pyspark.sql import functions as F
#
#    # aggregate data
#    df_trx_m = train.groupby('Age').agg(
#        F.avg(F.col('repatha_trx')).alias('repatha_trx_avg'),
#        F.variance(F.col('repatha_trx')).alias('repatha_trx_var')
#    )
#
#    df.agg({'Sales': 'sum'}).show()