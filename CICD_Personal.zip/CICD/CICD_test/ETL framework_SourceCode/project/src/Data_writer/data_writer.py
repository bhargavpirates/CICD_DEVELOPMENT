import traceback
import sys

class dataparatition:
    def partition_given(self, obj, partition_column="favorite_color"):
        """helper function for doing partitioning 

        Args:
            obj(pyspark.sql.readwriter.DataFrameWriter): writer object
            partition_column(str): column corresponding to which partition occurs      
        
        Returns:
            pyspark.sql.readwriter.DataFrameWriter: writer which does partitioning
        """
        return obj.partitionBy(partition_column)

    def bucket_given(self, obj, bucket_column="name", bucket_num=42):
        """helper function for doing bucketing

        Args:
            obj(pyspark.sql.readwriter.DataFrameWriter): writer object
            bucket_column(str): Buckets the output by the given column, or a list of columns.
            bucket_num(int): the number of buckets to save            
        
        Returns:
            pyspark.sql.readwriter.DataFrameWriter: writer which does bucketing
        """
        return obj.bucketBy(bucket_num, bucket_column)

    def partition_bucket_given(self, obj, partition_column="favorite_color", bucket_column="name", bucket_num=42):
        """helper function for doing partitioning and bucketing

        Args:
            obj(pyspark.sql.readwriter.DataFrameWriter): writer object
            partition_column(str): column corresponding to which partition occurs
            bucket_column(str): Buckets the output by the given column, or a list of columns.
            bucket_num(int): the number of buckets to save            
        
        Returns:
            pyspark.sql.readwriter.DataFrameWriter: writer which does partitioning and bucketing
        """
        return obj.partitionBy(partition_column).bucketBy(bucket_num, bucket_column)


class bigquery_writer:
    """class that saves/writes data from DataFrame into bigquery

    Args:
        df(pyspark.sql.dataframe.DataFrame): dataframe loaded from the corresponding file
        format_type(str): format in which data needs to be saved
        **mode_type(str): SaveMode, that specifies how to handle existing data if present.
        **project_bucketname(str): Gcs Bucket where the data needs to be written.
        **tablename(str): Table where the data needs to be written.
    
    """
    def __init__(self, df, format_type, **kwargs):
        self.df_write = df.write
        self.format_type = format_type
        self.df_write_obj = partition_logic(self.df_write, **kwargs)

    def writer(self, **kwargs):
        """save/write data from DataFrame into bigquery

        Args:
            **mode_type(str): SaveMode, that specifies how to handle existing data if present.
            **project_bucketname(str): Gcs Bucket where the data needs to be written.
            **tablename(str): Table where the data needs to be written.
        """
        try:
            self.df_write_obj \
                .format(self.format_type) \
                .mode(kwargs['mode_type']) \
                .option("temporaryGcsBucket", kwargs['project_bucketname']) \
                .option("table", "{}".format(kwargs['tablename'])) \
                .save()
        except:
            traceback.print_exc()
            print("Unable to write to Bigquery.")
            


class file_writer:
    """class that saves/writes data from DataFrame into file

    Args:
        df(pyspark.sql.dataframe.DataFrame): dataframe loaded from the corresponding file
        format_type(str): format in which data needs to be saved
        **mode_type(str): SaveMode, that specifies how to handle existing data if present.
        **path(str): path of folder where it should be saved
        **header(Boolean): This option is used to read the first line of the CSV file as column names
        **partition(Boolean): Include this only if partition is required
        **partition_column(str): column corresponding to which partition occurs
    """
    def __init__(self,df, format_type,  **kwargs):
        self.df_write = df.write
        self.format_type = format_type
        self.df_write_obj = partition_logic(self.df_write, **kwargs)

    def writer(self, **kwargs):
        """save/write data from DataFrame into file

        Args:
            **mode_type(str): SaveMode, that specifies how to handle existing data if present.
            **path(str): path of folder where it should be saved
            **header(Boolean): This option is used to read the first line of the CSV file as column names
            **partition(Boolean): Include this only if partition is required
            **partition_column(str): column corresponding to which partition occurs
        """
        try:
            if 'header' in kwargs.keys() and kwargs['header']==True:
                self.df_write_obj = self.df_write_obj.option('header',True)
                
            self.df_write_obj \
                .format(self.format_type) \
                .mode(kwargs['mode_type']) \
                .save(kwargs['path'])
        except:
            traceback.print_exc()
            print("Error writing to file")
            


class hive_writer:
    """class that saves/writes data from DataFrame into hive

    Args:
        df(pyspark.sql.dataframe.DataFrame): dataframe loaded from the corresponding file
        format_type(str): format in which data needs to be saved
        **mode_type(str): SaveMode, that specifies how to handle existing data if present.
        **tablename(str): name of the table.
        **header(Boolean): This option is used to read the first line of the CSV file as column names
        **partition(Boolean): Include this only if partition is required
        **partition_column(str): column corresponding to which partition occurs
        **bucket(Boolean): Include this only to bucket the output by the given columns
        **bucket_column(str): Buckets the output by the given column, or a list of columns.
        **bucket_num(int): the number of buckets to save
    """
    def __init__(self, df, format_type,**kwargs):
        self.df_write = df.write
        self.format_type = format_type
        self.df_write_obj = partition_logic(self.df_write, **kwargs)

    def writer(self, **kwargs):
        """save/write data from DataFrame into hive

        Args:
            **mode_type(str): SaveMode, that specifies how to handle existing data if present.
            **tablename(str): name of the table.
            **header(Boolean): This option is used to read the first line of the CSV file as column names
            **partition(Boolean): Include this only if partition is required
            **partition_column(str): column corresponding to which partition occurs
            **bucket(Boolean): Include this only to bucket the output by the given columns
            **bucket_column(str): Buckets the output by the given column, or a list of columns.
            **bucket_num(int): the number of buckets to save
        """
        try:
            if 'header' in kwargs.keys() and kwargs['header']==True:
                self.df_write_obj = self.df_write_obj.option('header',True)
                
            self.df_write_obj \
                .format(self.format_type) \
                .mode(kwargs['mode_type']) \
                .saveAsTable(kwargs['tablename'])
        except:
            traceback.print_exc()
            print("Error writing to file")
            


def partition_logic(write_obj, **kwargs):
    """helper function for doing partitioning and bucketing

    Args:
        write_obj
        **format_type(str): format in which data needs to be saved 
        **mode_type(str): SaveMode, that specifies how to handle existing data if present.
        **path(str): path of folder where it should be saved
        **partition(Boolean): Include this only if partition is required
        **partition_column(str): column corresponding to which partition occurs
        **bucket(Boolean): Include this only to bucket the output by the given columns
        **bucket_column(str): Buckets the output by the given column, or a list of columns.
        **bucket_num(int): the number of buckets to save
        **tablename(str): name of the table. Used when write_type is hive or bigquery
        **header(Boolean): This option is used to read the first line of the CSV file as column names
        **project_bucketname(str): Gcs Bucket where the data needs to be written.
    
    Returns:
        writer_obj(pyspark.sql.readwriter.DataFrameWriter): writer which does partitioning,bucketing or both partitioning and bucketing
    """
    try:
        dp_obj = dataparatition()
        key_lst = [key.lower() for key in kwargs.keys()]
        if (("partition" in key_lst) and ("bucket" in key_lst )):
            return dp_obj.partition_bucket_given(write_obj, kwargs['partition_column'], kwargs['bucket_column'],
                                                kwargs['bucket_num'])
        elif ("partition" in key_lst):
            return dp_obj.partition_given(write_obj, kwargs['partition_column'])
        elif ("bucket" in key_lst):
            return dp_obj.bucket_given(write_obj, kwargs['bucket_column'], kwargs['bucket_num'])
        else:
            return write_obj
    except:
        traceback.print_exc()
        print("Error partitioning.")
        


class WriterFactory:
    @staticmethod
    def build_writer(write_type, df, **kwargs):
        """save/write data from DataFrame

        Args:
            write_type(str): format in which data should be written 
            df(pyspark.sql.dataframe.DataFrame): dataframe loaded from the corresponding file
            **format_type(str): format in which data needs to be saved 
            **mode_type(str): SaveMode, that specifies how to handle existing data if present.
            **path(str): path of folder where it should be saved
            **partition(Boolean): Include this only if partition is required
            **partition_column(str): column corresponding to which partition occurs
            **bucket(Boolean): Include this only to bucket the output by the given columns
            **bucket_column(str): Buckets the output by the given column, or a list of columns.
            **bucket_num(int): the number of buckets to save
            **tablename(str): name of the table. Used when write_type is hive or bigquery
            **header(Boolean): This option is used to read the first line of the CSV file as column names
            **project_bucketname(str): Gcs Bucket where the data needs to be written.
        """
        if write_type=="bigquery":
            writer_obj = bigquery_writer(df,  format_type=write_type, **kwargs)
        elif write_type in ("csv","parquet","orc","txt","json"):
            writer_obj = file_writer(df, **kwargs)
        #elif write_type =='excel':
        #    return excel_reader(format_type=write_type,  **kwargs)
        elif write_type =='hive':
            writer_obj = hive_writer(df, **kwargs)

        writer_obj.writer(**kwargs)


def spark_writer(write_type, df, **kwargs):
    """save/write data from DataFrame to bigquery table, hive(with/without partitioning and bucketing).It can
    save in different formats("csv","parquet","orc","txt","json") 

    Args:
        write_type(str): format in which data should be written 
        df(pyspark.sql.dataframe.DataFrame): dataframe loaded from the corresponding file
        **format_type(str): format in which data needs to be saved 
        **mode_type(str): SaveMode, that specifies how to handle existing data if present.
        **path(str): path of folder where it should be saved
        **partition(Boolean): Include this only if partition is required
        **partition_column(str): column corresponding to which partition occurs
        **bucket(Boolean): Include this only to bucket the output by the given columns
        **bucket_column(str): Buckets the output by the given column, or a list of columns.
        **bucket_num(int): the number of buckets to save
        **tablename(str): name of the table. Used when write_type is hive or bigquery
        **header(Boolean): This option is used to read the first line of the CSV file as column names
        **project_bucketname(str): Gcs Bucket where the data needs to be written for bigquery.

    For writing file into "csv","parquet","orc","txt","json" without bucketing providing write_type, df, mode_type, path, format_type is mandatory

    >>> spark_writer('csv',df,mode_type='overwrite',path='csv_mod',format_type='csv',partition=True,partition_column="dept",header=True)

    For writing file into "csv","parquet","orc","txt","json" with bucketing providing write_type, df, mode_type, tablename, format_type, bucket, bucket_num, bucket_column is mandatory. 
    write_type = "hive" when bucketing is necessary.

    >>> spark_writer('hive',df,mode_type='overwrite',tablename='csv_mod',format_type='csv',bucket=True,bucket_num=3,bucket_column="dept",header=True)
    >>> spark_writer('hive',df,mode_type='overwrite',tablename='csv_mod3',format_type='csv',partition=True,partition_column='dept',bucket=True,bucket_num=3,bucket_column="salary",header=True)

    For writing file into bigquery table providing write_type, df, mode_type, project_bucketname, tablename is mandatory

    >>> spark_writer('bigquery',df,mode_type='overwrite',project_bucketname='gdw-dev-smai-vtctrimopt-default',tablename='auditing_dataset.test_table')
    """
    write_type = write_type.lower()
    WriterFactory.build_writer(write_type, df, **kwargs)
