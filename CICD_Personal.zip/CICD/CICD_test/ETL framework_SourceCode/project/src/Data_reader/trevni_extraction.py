import traceback
import sys

class DataExtractionTrevni:

    def __init__(self,sparksession):
        self.spark=sparksession

    def query_prep(self, query_exp=None, query_lst=[]):  #designid:"z41c",fab:16
        """Prepares query if either query expresion in query_exp or list of queries in query_lst are given. 

        Args:
            query_exp (str):  query expression
            query_lst ([str]):  list of queries

        Returns:
            str: prepared query 

        If query_exp is provided, every letter gets converted to UPPER case

        >>> print query_prep(query_exp="DESIGN_ID='Z41C' and PROCESS_ID='RPP'")
        "DESIGN_ID='Z41C' AND PROCESS_ID='RPP'"

        If query_lst is provided, elements in the list are joined with 'and' to 
        form the query and ever letter gets converted to upper case

        >>> print query_prep(query_lst=["DESIGN_ID='Z41C'","PROCESS_ID='RPP'"])
        "DESIGN_ID='Z41C' AND PROCESS_ID='RPP'"
        """
        try:
            if((query_exp==None) and (len(query_lst)==0)):
                print("please provide valid query_expression or query_expression_list")
                sys.exit(1)
            elif(query_exp != None):
                if query_exp[0]!='{':
                    query_exp =query_exp.upper()
                return query_exp
            elif(len(query_lst)>0):
                query = " and ".join(query_lst)
                query =query.upper()
                return query
        except:
            traceback.print_exc()
            

    def field_prep(self, field_list=[], field_string=None):
        """Prepares field if either fields in string format given in field_string or list of fields in field_list is given.

        Args:
            field_list ([str]):  list of fields required
            field_string (str):  string containing all the fields joined using ','

        Returns:
            str: prepared field

        If field_string  is provided, every letter gets converted to UPPER case  

        >>> print field_prep(field_string="FID,start_lot_key,WAFER_SCRIBE")
        "FID,START_LOT_KEY,WAFER_SCRIBE"

        If field_list is provided, elements in the list are joined with ',' and returns the field with ever letter '
        in upper case

        >>> print field_prep(field_list = ["FID","start_lot_key","WAFER_SCRIBE"])
        "FID,START_LOT_KEY,WAFER_SCRIBE"
        """
        try:
            if((field_string==None) and (len(field_list)==0)):
                print("please provide  valid  field_string  or field_string_list")
                sys.exit(1)
            elif(len(field_list)>0):
                fields=",".join(field_list)
                return fields.upper()
            elif(field_string!=None):
                return  field_string.upper()
        except:
            traceback.print_exc()
            

    def data_reader(self, fields, query,  jar="trevni2",group='',keys=''):
        """Prepare dataframe with required fields from query.

        Args:
            fields (str): string containing all the fields joined using ','
            query (str):  string containing query
            jar(str): provide implementation of the trevni jar
            keys(str): keys is used to extract data in tall format for "trevni2"
            group(str): fields that are used to groupby while using "Trevnikv"
        
        Returns: 
            pyspark.sql.dataframe.DataFrame: dataframe corresponding to field,query and jar

        >>> df = trevni_output(fields="FID,START_LOT_KEY,WAFER_SCRIBE", query="DESIGN_ID='Z41C' AND PROCESS_ID='RPP'")
        """        
        try:
            if(jar=='trevni'):
                file=query
                df = self.spark.read.format('com.micron.spark.probe.trevni').options(fields=fields).load(file)
            elif jar=="trevnikv":
                file=query
                if group!='':
                    df = self.spark.read.format('com.micron.spark.probe.trevnikv').options(group=group, fields=fields).load(file)
                else:
                    df = self.spark.read.format('com.micron.spark.probe.trevnikv').options(fields=fields).load(file)
            elif jar=='trevni2':
                # print(f"self.spark.read.format('com.micron.spark.probe.trevni2').options(fields={fields}).load({query})")
                if keys!='':
                    df = self.spark.read.format('com.micron.spark.probe.trevni2').options(fields=fields,keys=keys).load(query)
                else:
                    df = self.spark.read.format('com.micron.spark.probe.trevni2').options(fields=fields).load(query)
            return df
        except:
            traceback.print_exc()
            

    def trevni_output(self, fields, query,jar="trevni2",group='',keys=''):
        """Prepare dataframe with required fields from query.

        Args:
            fields(str/[str]): Provide fields which are to be present in dataframe if read_type is "trevni", "trevni2", "Trevnikv"
            query(str/[str]): For trevni2 ,provide the condition. For trevni and Trevnikv give the path of the file
            jar(str): provide implementation of the trevni jar
            keys(str): keys is used to extract data in tall format for "trevni2"
            group(str): fields that are used to groupby while using "Trevnikv"
        
        Returns: 
            pyspark.sql.dataframe.DataFrame: dataframe corresponding to field,query and jar.

        >>> df = trevni_output(fields="FID,START_LOT_KEY,WAFER_SCRIBE", query="DESIGN_ID='Z41C' and PROCESS_ID='RPP'")
        >>> df = trevni_output(fields="FID,START_LOT_KEY,WAFER_SCRIBE", query=["DESIGN_ID='Z41C","PROCESS_ID='RPP'"])
        >>> df = trevni_output(fields=["FID","start_lot_key","WAFER_SCRIBE"], query="DESIGN_ID='Z41C' and PROCESS_ID='RPP'")
        >>> df = trevni_output(fields=["FID","start_lot_key","WAFER_SCRIBE"], query=["DESIGN_ID='Z41C","PROCESS_ID='RPP'"])
        """  
        try:
            prep_field = ""
            prep_query = ""
            if jar in ('trevnikv'):
                prep_field = fields
            else:
                if isinstance(fields,str):
                    prep_field = self.field_prep(field_string=fields)
                else:
                    prep_field = self.field_prep(field_list=fields)
            prep_query = query
            if jar in ('trevni','trevnikv'):
                prep_query = query
            else:
                if isinstance(query,str):
                    prep_query = self.query_prep(query_exp=query)
                else:
                    prep_query = self.query_prep(query_lst=query)
            
            df = self.data_reader(prep_field,prep_query,jar,group,keys)
            return df
        except:
            traceback.print_exc()
            