"""
run.py in Framework is a boilerplate code for running a job in a cluster. 
Parts of the code are explained and sample run.py is shown at the end.

Importing DataprocCluster to setup the cluster and run the job.

>>> from dataproc_setup_class import DataprocCluster

| If project files are in local system use build_and_copy_gcsbucket from deploy_code_to_GCS to dump the files into gcs bucket which enables to use dataproc for runnig job

>>> from deploy_code_to_GCS import build_and_copy_gcsbucket
>>> build_and_copy_gcsbucket(dirname="test_proj",build_folder_name="dist", gcsbucket="gdw-dev-smai-vtctrimopt-default",gcsblob="VTC-Trim/Scripts/Monitoring/Test")

| args dictionary is used to configure dataproc.     
| cluster_name: Name of the cluster to be created.
| project_id: ID of the project corresponding to the cluster.
| region: Region where the cluster will be initialized.

>>> args={
    'cluster_name': 'test-new-code-12',
    'project_id' : 'gdw-dev-smai-vtctrimopt',
    'region': 'us-west1',
}

| cluster_params is used to configure cluster
| master_machine_type: Specification of master node.
| child_machine_type: Specification of child nodes.
| num_of_workers : Specify number of worker nodes.
| image_version : Specify OS Distribution.

>>> cluster_params={
    'master_machine_type': "n1-standard-4",
    'child_machine_type': "n1-standard-4",
    'num_of_workers': 4,
    "image_version": '2.0-debian10'
}

| run_params contains specifications corresponding to the job to be run.
| main_python_file: main_python_file_uri
| config_file([str]): URI of config files containing parameters used by the main python file.User sets up this configure file according to the use case.
| pythonfiles: python_file_uris(helper python files)
| args_list: arguments for main python file

>>> run_params={
    'main_python_file' : "gs://gdw-dev-smai-vtctrimopt-default/VTC-Trim/Scripts/Monitoring/Test/dist/preprocessing_main_latest.py",
    'config_file' : ["gs://gdw-dev-smai-vtctrimopt-default/VTC-Trim/Scripts/Monitoring/Test/dist/config_monitoring.yml"],
    'pythonfiles' : ["gs://gdw-dev-smai-vtctrimopt-default/VTC-Trim/Scripts/Monitoring/Test/dist/src.zip"],
    'args_list' : ['monitoring']
}
 
| Steps to run a pyspark job: 
| 1. Initialization of Dataproc Cluster Class

>>> d=DataprocCluster(**args)

| 2. Create Cluster.

>>> d.create_cluster(**cluster_params)
>>> d.wait_for_cluster_creation()

| 3. Run job.

>>> d.submit_pyspark_job(**run_params)

| 4. Delete Cluster.

>>> d.delete_cluster()

Below is the sample run.py that uses modules from framework to run a specific pyspark job in a cluster of specified configuration. 

>>> from dataproc_setup_class import DataprocCluster
>>> from deploy_code_to_GCS import build_and_copy_gcsbucket
>>> dirname = "test_proj"
>>> build_folder_name = "dist"
>>> gcsbucket = "gdw-dev-smai-vtctrimopt-default"
>>> gcsblob = "project_deploy_testing"
>>> cluster_name = "test-cluster"
>>> build_and_copy_gcsbucket(dirname=dirname,build_folder_name=build_folder_name, gcsbucket=gcsbucket,gcsblob=gcsblob)
>>> args={
    'cluster_name': cluster_name,
    'project_id' : 'gdw-dev-smai-vtctrimopt',
    'region': 'us-west1',
}
>>> cluster_params={
    'master_machine_type': "n1-standard-4",
    'child_machine_type': "n1-standard-4",
    'num_of_workers': 4,
    "image_version": '2.0-debian10'
}
>>> run_params={
    'main_python_file' : f"gs://{gcsbucket}/{gcsblob}/{build_folder_name}/preprocessing_main_latest.py",
    'config_file' : [f"gs://{gcsbucket}/{gcsblob}/{build_folder_name}/config_monitoring.yml"],
    'pythonfiles' : [f"gs://{gcsbucket}/{gcsblob}/{build_folder_name}/src.zip"],
    'args_list' : ['monitoring']
}
>>> d=DataprocCluster(**args)
>>> d.create_cluster(**cluster_params)
>>> d.wait_for_cluster_creation()
>>> d.submit_pyspark_job(**run_params)
>>> d.delete_cluster()
"""

from dataproc_setup_class import DataprocCluster
from deploy_code_to_GCS import build_and_copy_gcsbucket

dirname = "project"
build_folder_name = "dist"
gcsbucket = "gdw-dev-smai-vtctrimopt-default"
gcsblob = "project_deploy_testing"
cluster_name = "test-cluster"

build_and_copy_gcsbucket(dirname=dirname,build_folder_name=build_folder_name, gcsbucket=gcsbucket,gcsblob=gcsblob)

args={
    'cluster_name': cluster_name,
    'project_id' : 'gdw-dev-smai-vtctrimopt',
    'region': 'us-west1',
}

cluster_params={
    'master_machine_type': "n1-standard-4",
    'child_machine_type': "n1-standard-4",
    'num_of_workers': 30,
    "image_version": '2.0-debian10'
}

run_params={
    'main_python_file' : f"gs://{gcsbucket}/{gcsblob}/{build_folder_name}/project_main.py",
    'config_file' : [],
    'pythonfiles' : [f"gs://{gcsbucket}/{gcsblob}/{build_folder_name}/src.zip"],
    'args_list' : []
}


d=DataprocCluster(**args)
d.create_cluster(**cluster_params)
d.wait_for_cluster_creation()
d.submit_pyspark_job(**run_params)
d.delete_cluster()



