#=========================================================================================
#     Import python libraries
#=========================================================================================
import os
import shutil
import traceback
import subprocess

import sys
import glob
import argparse
from google.cloud import storage
#=========================================================================================
#     Helper Methods
#=========================================================================================

def delete(path):
    """Delete the specified directory or file.

    Args:
        path (str): The path to the directory or file to be deleted.

    Raises:
        ValueError : If the path does not represent a valid directory or file.
    """
    if os.path.isfile(path) :
        os.remove(path)
    elif os.path.isdir(path):
        shutil.rmtree(path)
    else:
        raise ValueError("Path {} is not a file or dir.".format(path))

def create_directory(path):
    """Create the specified directory.

    Args:
        path (str): The directory to be created.

    """
#    Raises:
#        ValueError : If the path does not represent a valid directory or file.
    if os.path.isdir(path):
        print("Directory already exists with that name")
        # raise ValueError("Path {} already exists.".format(path))
    else:
        os.mkdir(path)


def copy_file(source_path,dest_path):
    """Copy the given file to the specified Location

    Args:
        source_path (str): The path th the source file.
        dest_path (str): The path to which the file should be copied.

    Raises:
        PermissionError : If the path represents a folder instead of a file.
    """
    try:
        if os.path.isfile(os.path.join(dest_path,os.path.split(source_path)[1])):
            print("File already exists with that name")
        else:
            shutil.copy(source_path, dest_path)
    except PermissionError:
        print("Source path represents folder.")


def create_zip_folder(source_foldername, dest_dir_name):
    """Create a zip archive of the given source folder.

    Args:
        source_foldername (str): The path to the directory to be archived.
        dest_dir_name (str): The path which the archive should be saved.
    """
    shutil.make_archive(dest_dir_name, 'zip', source_foldername)


def list_filenames(dirname):
    """Get names of all files present in given directory.

    Args: 
        dirname (str): The directory whose files are to be known.
    
    Returns:
        [str]: Names of all the files in that directory, specifically those with .py or .yml extension.

    Examples:
        >>> list_filenames("test_proj")
        ['repair_density.py',
        'least_rank_cost.py',
        'preprocessing_main_latest.py',
        'dummy.py',
        'config_monitoring.yml',
        'repair_density_1.py',
        'ttr_metric.py',
        'deployment_file.py',
        'test_monitoring.yml',
        'most_frequent_trim_knobs.py',
        'monitoring_main.py',
        'preprocessing_main.py',
        'dies_require_lineardescent.py']
        >>> list_filenames("test_proj/src")
        ['crediental_setup.py',
        'crediental_setup_v1.py',
        'gcs_class.py',
        'gcs_main.py',
        'crediental_setup_testing.py',
        'gcs_main_v2.py']
    """
    path=os.path.join(os.getcwd())
    fullpath=os.path.join(path,dirname)
    res=os.listdir(os.path.join(path,dirname))
    onlyfiles = [ f for f in res if os.path.splitext(os.path.join(fullpath, f))[1]  in [".py",".yml"] ]
    #print("\n".join(onlyfiles))
    return onlyfiles


#=========================================================================================
#     Run MakeFile
#=========================================================================================
def Makefile(filenames,dirname, build_folder_name="dist"):
    """Copy the specified files from the given directory to a build directory having he specified name.

    The build folder is created within the project directory(dirname) itself.
    The src directory is made to a zip archive and saved to the build folder.

    Args:
        filenames ([str]): List of names all the files to be copied.
        dirname (str): The directory containing the listed files.
        build_folder_name (str): The name to be given to the build folder.

    Examples:
        >>> Makefile(l, "test_proj", "build")
        >>> os.path.isdir("test_proj/build")
        True
        >>> os.listdir("test_proj/build")
        ['repair_density.py',
        'least_rank_cost.py',
        'preprocessing_main_latest.py',
        'dummy.py',
        'config_monitoring.yml',
        'repair_density_1.py',
        'src.zip',
        'ttr_metric.py',
        'deployment_file.py',
        'test_monitoring.yml',
        'most_frequent_trim_knobs.py',
        'monitoring_main.py',
        'preprocessing_main.py',
        'dies_require_lineardescent.py']
    """
    try:
        path=os.getcwd()
        fullpath=os.path.join(path,dirname,build_folder_name)
        if(os.path.isdir(fullpath)):
            delete(fullpath)
        create_directory(fullpath)
        for file in filenames:
            source_path = os.path.join(os.getcwd(), dirname, file)
            copy_file(source_path, fullpath)
        create_zip_folder(os.path.join(path, dirname, 'src'),
                        os.path.join(fullpath, "src"))
    except:
        traceback.print_exc()
        



#dirname="auditbalancing"
#filenames=list_filenames(dirname)
#build_folder_name="dist"
#Makefile(filenames, dirname, build_folder_name)

#==================================================================================================================================================




class DeployCode:
    """Helper Class for deploying code to gcs bucket.
    """

    def files_in_folder(self, project_folder_path="", platform="unix", verbose=None):
        """Get names of all files in the given project

        Args:
            project_folder_path (str): path to the folder containing the project.

        Returns:
            [str]: List of names of all the files in the given project.
        """
        try:
            total_flies_lst = []
            for name in glob.glob(project_folder_path):
                if (os.path.isdir(name)):
                    a = self.files_in_folder(project_folder_path=name + "/*")
                    if (len(a) != 0):
                        total_flies_lst.extend(a)
                else:
                    total_flies_lst.append(name)

            return total_flies_lst
        except:
            traceback.print_exc()
            



    def project_struct(self, file_lst, name):
        """Get relative paths of files from within the project folder.

        Args:
            file_lst ([str]): List of full path of the files inside the directory.
            name (str): Path to the project folder.
        
        Returns:
            [str]: List of relative paths to files from the parent folder.
        """
        try:
            final_project_structure = []
            for filenames in file_lst:
                #print(filenames)
                final_project_structure.append(filenames.replace(name[:-1], ""))
            return final_project_structure
        except:
            traceback.print_exc()
            



    def multi_upload_blob_dataproc(self, bucket_name, sourcepath, source_filenamelist, destination_path, independent_folder):
        """Uploads a list of files from build folder to the specified bucket.

        Args:
            bucket_name (str): Name of the target bucket.
            sourcepath (str): Path containing the files to be copied.
            source_filenamelist ([str]): List of names of all the files to be copied.
            destination_path (str): path corresponding to the destination blob.
            independent_folder: The build directory within the project folder.
        """
        try:
            client = storage.Client()
            bucket = client.bucket(bucket_name)
            #print("*"*200)
            for source_file_name in source_filenamelist:
                if(source_file_name.split('/')[0] == independent_folder):
                    #print(source_file_name)
                    #destination_blob_name = destination_path + source_file_name
                    destination_blob_name = os.path.join(destination_path ,source_file_name.replace("\\","/"))
                    destination_blb = destination_blob_name
                    blob = bucket.blob(destination_blb)
                    #print(sourcepath + source_file_name)
                    blob.upload_from_filename(sourcepath  + source_file_name)
                    print("File {} uploaded to {}.".format(source_file_name, destination_blob_name))
        except:
            traceback.print_exc()
            




    def localfolder_gcp_files_dump(self, bucketname="gdw-dev-smai-vtctrimopt-default", foldername="",
                                gcsfolder="VTC-Trim/DUMMY/", independent_folder=""):
        """Copy files from local directory to GCS bucket.

        Args:
            foldername (str): The path corresponding to the source folder.
            bucketname (str): The bucketname to which the folder should be copied.
            gcsfolder (str): The blob name under which the files should be saved.
            independent_folder (str): The build directory within the project folder.
        """
        try:
            #print(foldername)
            get_all_files_in_folder = self.files_in_folder(foldername)
            #print(get_all_files_in_folder)
            #print("*" * 100)
            final_project_structure = self.project_struct(get_all_files_in_folder, foldername)
            self.multi_upload_blob_dataproc(bucketname, foldername[:-1], final_project_structure, gcsfolder, independent_folder)
        except:
            traceback.print_exc()
            




    def copy_files_into_gcs_bucket(self, localfolder_name, gcs_bucketname, gcs_blobname, build_folder):
        """Copy files from local directory to GCS bucket.

        Args:
            localfolder_name (str): The name of the source folder.
            gcs_bucketname (str): The bucketname to which the folder should be copied.
            gcs_blobname (str): The blob name under which the files should be saved.
            build_folder (str): The folder containing the build files.

        Examples:
            >>> obj = DeployCode()
            >>> obj.copy_files_into_gcs_bucket("test_proj", "gdw-dev-smai-vtctrimopt-default", "project_deploy_testing/")
            File dist/dummy.py uploaded to project_deploy_testing/dist/dummy.py.
            File dist/config_monitoring.yml uploaded to project_deploy_testing/dist/config_monitoring.yml.
            File dist/repair_density_1.py uploaded to project_deploy_testing/dist/repair_density_1.py.
            File dist/src.zip uploaded to project_deploy_testing/dist/src.zip.
            File dist/ttr_metric.py uploaded to project_deploy_testing/dist/ttr_metric.py.
        """
        try:
            current_path = os.getcwd()
            foldername = os.path.join(current_path, localfolder_name, "*")
            gcsfolder = gcs_blobname
            self.localfolder_gcp_files_dump(foldername=foldername, bucketname=gcs_bucketname , gcsfolder=gcsfolder, independent_folder=build_folder)
        except:
            traceback.print_exc()
            



#===========================================================================================================================================
def build_and_copy_gcsbucket(dirname="",build_folder_name="", gcsbucket="",gcsblob="VTC-Trim/Scripts/Monitoring/Test_latest/"):
    """Build and Deploy project to the specified GCS Bucket.

    Args:
        dirname (str): The name of the folder which contains the project files.
        build_folder_name (str): The name to be given to the build folder.
        gcsbucket (str): The bucketname to which the project should be deployed.
        gcsblob (str): The blob name under which the project should be saved within the bucket.
    
    Example:
        >>> build_and_copy_gcsbucket(dirname="test_proj",build_folder_name="dist", gcsbucket="gdw-dev-smai-vtctrimopt-default",gcsblob="project_deploy_testing/")
        File dist/repair_density.py uploaded to project_deploy_testing/dist/repair_density.py.
        File dist/least_rank_cost.py uploaded to project_deploy_testing/dist/least_rank_cost.py.
        File dist/preprocessing_main_latest.py uploaded to project_deploy_testing/dist/preprocessing_main_latest.py.
        File dist/dummy.py uploaded to project_deploy_testing/dist/dummy.py.
        File dist/src.zip uploaded to project_deploy_testing/dist/src.zip
        File dist/preprocessing_main.py uploaded to project_deploy_testing/dist/preprocessing_main.py.
        File dist/dies_require_lineardescent.py uploaded to project_deploy_testing/dist/dies_require_lineardescent.py.
    """
    try:
        dc=DeployCode()
        #build job
        filenames=list_filenames(dirname)
        Makefile(filenames, dirname, build_folder_name)
        #copy files into gc_bucket
        dc.copy_files_into_gcs_bucket(localfolder_name=dirname, gcs_bucketname=gcsbucket, gcs_blobname=gcsblob , build_folder=build_folder_name)
    except:
        traceback.print_exc()
        


#build_and_copy_gcsbucket(dirname="bigquery",build_folder_name="dist", gcsbucket="gdw-dev-smai-vtctrimopt-default",gcsblob="project_deploy_test/")

